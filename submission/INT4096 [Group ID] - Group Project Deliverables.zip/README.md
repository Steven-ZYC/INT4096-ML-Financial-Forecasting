# INT4096 Group Project Deliverables

Learning Machine Learning Through Financial Time-Series Forecasting.
The report is uploaded separately as a PDF.

| File | What it is |
|---|---|
| `Presentation/INT4096_Presentation.pdf` | Presentation slides |
| `Notebook/INT4096_Final_Colab.ipynb` | Self-contained notebook: code and data inside |
| `Notebook/INT4096_Final_Colab_executed.ipynb` | The same notebook with saved outputs from a full run |
| `Dataset/aapl_daily.json` | Original Apple (AAPL) daily data |
| `Dataset/aapl_daily.manifest.json` | AAPL source record and fingerprint |
| `Dataset/btc_daily.json` | Original Bitcoin (BTC/USDT) daily data |
| `Dataset/btc_daily.manifest.json` | BTC source record and fingerprint |
| `Lesson/lesson_plan.md` | 60-minute lesson plan |
| `Lesson/formative_tasks.md` | Five formative tasks with answers |
| `Lesson/teacher_notes.md` | Teacher notes |

## Run the notebook

Open `Notebook/INT4096_Final_Colab.ipynb` in Jupyter or VS Code and choose
**Run All**. It needs no other files. The first cell installs missing Python
packages. The neural-network section also needs PyTorch and is skipped without it.
The saved outputs can be read in the executed copy without running anything.

Repository: https://github.com/Steven-ZYC/INT4096-ML-Financial-Forecasting

Educational and historical only. Not investment advice.
